BIMWiz Installer Package - 1.0.3
Developer: Muhammed Abid
Company: Acube Developments

CONTENTS
  installer.exe                  Install / Repair / Uninstall / Troubleshooting
  BIMWiz logo png.png             Transparent BIMWiz logo
  Acube logo.png                  Black Acube logo with its original transparency
  BIMWiz-Panels.log                Panel and button inventory, including port status
  payload\2024\BIMWiz.Addin.dll    Revit 2024 build (.NET Framework 4.8)
  payload\2026\BIMWiz.Addin.dll    Revit 2026 build (.NET 8, installed API 26.3.0.0)
  payload\2026\BIMWiz.Addin.deps.json
  payload\<year>\version.txt
  payload\<year>\BIMWiz-Panels.log

INSTALL
  Extract the entire ZIP to a folder. Keep installer.exe, both logos, the log,
  and the payload folder together. Run installer.exe, select 2024 and/or 2026,
  and choose Install. Repair re-stages the selected release and registration.
  The .NET SDK is only required to rebuild the source, not to use the installer.

UPDATE
  Replace the appropriate year's DLL and supporting files under payload\<year>,
  update version.txt, and run the same installer. Files are staged in a new
  release folder, so the installer can run while Revit remains open. The running
  Revit session keeps its loaded code; changes take effect at the next launch.
  This package does not reload commands into an already running Revit session.

VERSION SUPPORT
  2024 and 2026 have separate compiled payloads. The 2026 build references the
  installed Autodesk API version 26.3.0.0. Commands have not yet been exercised
  inside a Revit model. Earlier 2026 updates are not runtime-verified.
  Later Revit years require a build and validation against that year's API and
  runtime. Add its payload\<year> folder to expose its checkbox automatically.

TOOL STATUS
  Sheets: Exporter, Paste2Sheets, Renamer are ported to C#.
  The other ten ribbon commands remain pending. See BIMWiz-Panels.log.

SUPPORT
  Troubleshooting opens an email draft to abid.thachakath@acube.ae for review
  and sending. It does not send automatically. Runtime installer activity is
  recorded at %LOCALAPPDATA%\BIMWiz\installer.log.

REBUILD
  In the separate source package, run src\Build.ps1. It detects the user-local
  SDK installed at %LOCALAPPDATA%\BIMWiz\BuildTools\dotnet8\dotnet.exe.
  Microsoft .NET SDK 8.0.425 and its targeting packs were installed there.
  Both local Revit API installations are required to rebuild both payloads.


